import React from 'react';

const fileUpload = () => {
  return <div>fileUpload</div>;
};

export default fileUpload;
